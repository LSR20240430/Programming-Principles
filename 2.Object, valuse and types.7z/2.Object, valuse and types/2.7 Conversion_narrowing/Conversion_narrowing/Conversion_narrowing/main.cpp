import std;

int main()
{

	double d = 0;

	while (std::cin >> d)
	{
		int i = d;
		char c = i;

		std::cout << "d ==" << d << " i ==" << i << " c ==" << c << " char(" << c << ")\n";


	}



	return 0;
}