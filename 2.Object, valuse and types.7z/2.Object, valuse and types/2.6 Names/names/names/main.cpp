import std;

int main()
{
	std::string s = "Goodbye, cruel world!";

	std::cout << s << "\n";


	return 0;

}