import std;

int main()
{
	double pennies = 0, nickels = 0, dimes = 0, quarters = 0, half_dollars = 0, one_dollar_coins = 0, total_dollar_cents = 0;

	std::cout << "How many pennies do you have: ";
	std::cin >> pennies;

	std::cout << "\nHow many nickels do you have: ";
	std::cin >> nickels;

	std::cout << "\nHow many dimes do you have: ";
	std::cin >> dimes;

	std::cout << "\nHow many quarters do you have: ";
	std::cin >> quarters;

	std::cout << "\nHow many half_dollars do you have: ";
	std::cin >> half_dollars;

	std::cout << "\nHow many one_dollar_coins do you have: ";
	std::cin >> one_dollar_coins;


	if (pennies == 1)
		std::cout << "\nYou have " << pennies << " pennie.";
	else
		std::cout << "\nYou have " << pennies << " pennies.";

	if (nickels == 1)
		std::cout << "You have " << nickels << " nickel.\n";
	else
		std::cout << "You have " << nickels << " nickels.\n";

	if (dimes == 1)
		std::cout << "You have " << dimes << " dime.";
	else
		std::cout << "You have " << dimes << " dimes.";

	if (quarters == 1)
		std::cout << "You have " << quarters << " quarter.\n";
	else
		std::cout << "You have " << quarters << " quarters.\n";

	if (half_dollars == 1)
		std::cout << "You have " << half_dollars << " half dollar.";
	else
		std::cout << "You have " << half_dollars << " half dollars.";

	if (one_dollar_coins == 1)
		std::cout << "You have " << one_dollar_coins << " one_dollar_coin.\n.";
	else
		std::cout << "You have " << one_dollar_coins << " one_dollar_coins.\n";

	total_dollar_cents = pennies + 5 * nickels + 10 * dimes + 25 * quarters + 50 * half_dollars + 100 * one_dollar_coins;

	total_dollar_cents = total_dollar_cents / 100;

	std::cout << "The value of all of your coins is " << total_dollar_cents << " dollars\n";




	return 0;
}