extern int x = 0;

import std;
int main()
{


	

	int z = 5;

	return 0;



}