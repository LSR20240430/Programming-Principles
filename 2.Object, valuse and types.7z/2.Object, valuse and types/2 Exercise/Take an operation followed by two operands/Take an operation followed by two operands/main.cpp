import std;

int main()
{
	std::string operation;
	
	double operand1 = 0, operand2 = 0;

	std::cout << "Please enter the string operation(+,-,*,/) and two operands: ";

	std::cin >> operation >> operand1 >> operand2;

	if (operation == "+")
		std::cout << "The result of operand1 + operand2 is: " << operand1 + operand2 <<"\n";
	else if (operation == "-")
		std::cout << "The result of operand1 - operand2 is: " << operand1 - operand2 <<"\n";
	else if (operation == "*")
		std::cout << "The result of operand1 * operand2 is: " << operand1 * operand2 << "\n";

	else if (operation == "/")
	{
		if (operand2 == 0)
			std::cout << "The result of operand1 / operand2 is error (operand2 = 0)"<< "\n";
		else
			std::cout << "The result of operand1 / operand2 is: " << operand1 / operand2 <<"\n";
	}
	else
		std::cout << "It is not a string I know\n";





	return 0;
}