import std;

int main()
{
	int val1 = 0;


	std::cout << "Please enter a integer value to determine if it is odd or even: ";

	std::cin >> val1;

	if (val1 % 2 != 0)
		std::cout << "The value "<< val1 << " is odd number\n";
	else
		std::cout << "The value "<< val1 << " is even number\n";

	

	return 0;
}