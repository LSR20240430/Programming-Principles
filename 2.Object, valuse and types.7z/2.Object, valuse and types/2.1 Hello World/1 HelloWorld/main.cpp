import std; // introduce  std library


// Output some character strings to screen.

int main() // programe strats with main function in c++
{

	std::cout << "Hello, programming!\n";   // cout is abbreviation of character out put stream; strings need to be delimited by double quotes
	std::cout << "Here we go!";            // "\n" denotes newline, the cursor will appear the start of next line

	return 0;  // the return value of function, only main function can leave it out.

}